import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;

public class TestWeather {

	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	static HashMap<Integer, HashMap<String, Object>> station1Data = new HashMap<Integer, HashMap<String, Object>>();
	
    @BeforeSuite(alwaysRun=true)
    public static void setup() {
    	System.out.println("^^^^^^^^^^^^^^ SET UP ^^^^^^^^^^^^^");
        RestAssured.baseURI = "http://localhost:8080";
        RestAssured.basePath = "/weather";
        
        
        HashMap<String, Object> data = new HashMap<String, Object>();
        data.put("temperature", new Float(60f));
        data.put("humidity", new Float(37.78f));
        data.put("precipitation", new Float(5.27f));
        station1Data.put(new Integer(1), data);
        
        data = new HashMap<String, Object>();
        data.put("temperature", new Float(75f));
        data.put("humidity", new Float(26.77f));
        data.put("precipitation", new Float(9.25f));
        station1Data.put(new Integer(34), data);
        
        data = new HashMap<String, Object>();
        data.put("temperature", new Float(61f));
        data.put("humidity", new Float(37.78f));
        data.put("precipitation", new Float(5.27f));
        station1Data.put(new Integer(20), data);
        
        data = new HashMap<String, Object>();
        data.put("temperature", new Float(62f));
        data.put("humidity", new Float(61.82f));
        data.put("precipitation", new Float(9.57f));
        station1Data.put(new Integer(21), data);
        
        data = new HashMap<String, Object>();
        data.put("temperature", new Float(60f));
        data.put("humidity", new Float(37.93f));
        data.put("precipitation", new Float(4f));
        station1Data.put(new Integer(8), data);
    }
    
    /**
     * Since Observation Id has to be unique, query the server for the next id for a given station id
     * 
     * @param stationId
     * @return
     */
    public String getNextObservationIdForStationId(String stationId) {
    	String id = given().contentType(ContentType.JSON).
		pathParam("stationId", stationId).
		when().get("{stationId}/nextObservationId").
		then().statusCode(200).extract().path("nextId");
		
    	System.out.println(">>>> Next id is : " + id);
    	return id;
    }
    
    /**
     * Generate random station id between 2 ~ 7
     * @return
     */
    public String getRandomStationId() {
    	Random rand = new Random();
    	return ""+(rand.nextInt(5) + 2);
    }
    
    /**
     * Scenario : Get next observation id for an existing station
     * Scenario : Get next observation id for non-existing station
     */
    @Test(groups={"Regression"})
    public void testGetNextObservationId() {
    	//Positive - existing station id
    	Assert.assertNotNull(getNextObservationIdForStationId("1"));
    	
    	//Negative - non existance station id = 404 Not found
    	given().contentType(ContentType.JSON).
		when().get("22/nextObservationId").
		then().statusCode(404);
    }
    
    /**
     * Scenario : Create an observation with full data
     * Scenario : Get observation by station id + observation id
     */
	@Test(groups={"BAT","Regression"})
	public void testCreateObservation() {
		String randomStationId = getRandomStationId();
		String nextObservationId = getNextObservationIdForStationId(randomStationId);
		
		//Post data to a station
		given().contentType("application/json").
		body("{\"temperature\": 88,\"humidity\": 68,\"precipitation\": 10,\"observationId\": " + nextObservationId + ",\"stationId\": " + randomStationId + ",\"timestamp\": \"" + sdf.format(new Date()) + "\"}").
		when().
		post().
		then().
		statusCode(201);
		

		//Retrieve the data we just posted and assert.
		given().contentType(ContentType.JSON)
		.pathParam("stationId", randomStationId)
		.pathParam("observationId", nextObservationId)
		.when()
		.get("{stationId}/{observationId}")
		.then()
		.statusCode(200)
		.body("humidity", equalTo(68.0f))
		.body("temperature", equalTo(88.0f))
		.body("precipitation", equalTo(10.0f));
		
	}
	
	/**
	 * Scenario : Get observations by station id 
	 * example : station id 1
	 * Expected : 5 results
	 */
	@Test(groups={"BAT","Regression"})
	public void testGetObservationByStationId() {
		Response r = given()
				.contentType("application/json")
				.when()
				.get("1")
				.then().statusCode(200)
				.extract()
				.response();
		
		
		List<HashMap> olist = r.getBody().jsonPath().get(".");
		Assert.assertTrue(olist.size()==5);
		
		for(int i = 0; i < olist.size(); i++) {
			HashMap<String, Object> o = olist.get(i);
			Object observationId = o.get("observationId");
			Object precipitation = o.get("precipitation");
			Object humidity = o.get("humidity");
			Object temperture = o.get("temperture");

			Assert.assertEquals(precipitation, station1Data.get(observationId).get("precipitation"));
			Assert.assertEquals(temperture, station1Data.get(observationId).get("temperture"));
			Assert.assertEquals(humidity, station1Data.get(observationId).get("humidity"));
		}
	}
	
	/** 
	 * Scenario : Get min temperture for a station id
	 * example : station id 1
	 * Expected : 60
	 */
	@Test(groups={"Regression"})
	public void testMin() {
		given()
		.contentType("application/json")
		.when()
		.get("1/min")
		.then()
		.statusCode(200)
		.body("min", equalTo(60f));
	}
	
	/**
	 * Scenario : Get min temperture for a station id + date range
	 * example : station id 1 between 2016-11-17 ~ 2016-11-19
	 * Expected : 61
	 */
	@Test(groups={"Regression"})
	public void testMinWithDateRange() {
		given()
		.contentType("application/json")
		.when()
		.param("fromDate", "2016-11-17")
		.param("toDate", "2016-11-19")
		.get("1/min")
		.then().statusCode(200)
		.body("min", equalTo(61f));
	}
	
	/**
	 * Scenario : Get max temperture for a station id
	 * example : station id 1
	 * Expected : 75
	 */
	@Test(groups={"Regression"})
	public void testMax() {
		given()
		.contentType("application/json")
		.when()
		.get("1/max")
		.then()
		.statusCode(200)
		.body("max", equalTo(75f));
	}
	
	/**
	 * Scenario : Get max temperture for a station id + date range
	 * example : station id 1 between 2016-11-17 ~ 2016-11-19
	 * Expected : 62
	 */
	@Test(groups={"Regression"})
	public void testMaxWithDateRange() {
		given()
		.contentType("application/json")
		.when()
		.param("fromDate", "2016-11-17")
		.param("toDate", "2016-11-19")
		.get("1/max")
		.then()
		.statusCode(200)
		.body("max", equalTo(62f));
	}
	
	/**
	 * Scenario : Get average temperature for a station id
	 * example : station id 1
	 * Expected : 63.6
	 */
	@Test(groups={"Regression"})
	public void testAvg() {
		given()
		.contentType("application/json")
		.when()
		.get("1/avg")
		.then()
		.statusCode(200)
		.body("avg", equalTo(63.6f));
	}
	
	/**
	 * Scenario : Get average temperature for a station id
	 * example : station id 1 between 2016-11-17 ~ 2016-11-19
	 * Expected : 61.5
	 */
	@Test(groups={"Regression"})
	public void testAvgWithDateRange() {
		given()
		.contentType("application/json")
		.when()
		.param("fromDate", "2016-11-17")
		.param("toDate", "2016-11-19")
		.get("1/avg")
		.then()
		.statusCode(200)
		.body("avg", equalTo(61.5f));
	}
	
	/**
	 * Scenario : Create Observation
	 * 	No station id
	 * 	No observation id
	 *  No temperature
	 *  No humidity
	 *  No precipitation
	 *  Duplicate observation id
	 */
	@Test(groups={"Regression"})
	public void testCreateNegative() {
		
		String randomStationId = getRandomStationId();
		String nextObservationId = getNextObservationIdForStationId(randomStationId);
		
		//No station id, No observation id (status 400, bad request)
		given().contentType("application/json").
		body("{\"temperature\": 88,\"humidity\": 68,\"precipitation\": 10, \"timestamp\": \"" + sdf.format(new Date()) + "\"}").
		when().
		post().
		then().
		statusCode(400);
		
		//No temperature (equals 0 temperature)
		given().contentType("application/json").
		body("{\"humidity\": 68,\"precipitation\": 10,\"observationId\": " + nextObservationId + ",\"stationId\": " + randomStationId + ",\"timestamp\": \"" + sdf.format(new Date()) + "\"}").
		when().
		post().
		then().
		statusCode(201);
		
		nextObservationId = getNextObservationIdForStationId(randomStationId);
		//No humidity
		given().contentType("application/json").
		body("{\"temperature\": 88,\"precipitation\": 10,\"observationId\": " + nextObservationId + ",\"stationId\": " + randomStationId + ",\"timestamp\": \"" + sdf.format(new Date()) + "\"}").
		when().
		post().
		then().
		statusCode(201);
		
		nextObservationId = getNextObservationIdForStationId(randomStationId);
		//No precipitation
		given().contentType("application/json").
		body("{\"temperature\": 88,\"humidity\": 68,\"observationId\": " + nextObservationId + ",\"stationId\": " + randomStationId + ",\"timestamp\": \"" + sdf.format(new Date()) + "\"}").
		when().
		post().
		then().
		statusCode(201);
		
		//duplicate observation id (status 409, conflict)
		given().contentType("application/json").
		body("{\"temperature\": 88,\"humidity\": 68,\"observationId\": 1,\"stationId\": 1,\"timestamp\": \"" + sdf.format(new Date()) + "\"}").
		when().
		post().
		then().
		statusCode(409);
	}
	
	/**
	 * Scenario : Get Min
	 * 	Invalid station id
	 */
	@Test(groups={"Regression"})
	public void testMinNegative() {
		
		//invalid station id = Not found
		given()
		.contentType("application/json")
		.when()
		.get("/45/min")
		.then()
		.statusCode(404);
		
		//missing date = Bad request
		given()
		.contentType("application/json")
		.when()
		.param("fromDate", "")
		.param("toDate", "")
		.get("1/min")
		.then().statusCode(400);
	}
	
	/**
	 * Scenario : Get Max
	 *  Invalid station id
	 */
	@Test(groups={"Regression"})
	public void testMaxNegative() {
		
		given()
		.contentType("application/json")
		.when()
		.get("/45/max")
		.then()
		.statusCode(404);
		
		//missing date = Bad request
		given()
		.contentType("application/json")
		.when()
		.param("fromDate", "")
		.param("toDate", "")
		.get("1/max")
		.then().statusCode(400);
	}
	
	/**
	 * Scenario : Get Avg
	 *  Invalid station id
	 */
	@Test(groups={"Regression"})
	public void testAvgNegative() {
		
		given()
		.contentType("application/json")
		.when()
		.get("/45/avg")
		.then()
		.statusCode(404);
		
		//missing date = Bad request
		given()
		.contentType("application/json")
		.when()
		.param("fromDate", "")
		.param("toDate", "")
		.get("1/avg")
		.then().statusCode(400);
	}
}
