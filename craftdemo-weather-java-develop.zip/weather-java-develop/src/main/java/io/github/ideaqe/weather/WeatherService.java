package io.github.ideaqe.weather;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.concurrent.ThreadSafe;
import javax.ws.rs.BadRequestException;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

@Path("/weather")
public class WeatherService {

	static SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
	{
		DATE_FORMAT.setTimeZone(TimeZone.getTimeZone("PST")); 
	}
    @Created
    @POST
    @Path("/")
    @Produces(MediaType.APPLICATION_JSON)
    public void createMeasurement(Observation observation) {
    	if (observation.stationId == 0 || observation.observationId == 0)
    		throw new BadRequestException();
        Observations.getInstance().add(observation);
    }

    @GET
    @Path("/{stationId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Observation> getObservations(@PathParam("stationId") int stationId) {
        return Observations.getInstance().getObservations(stationId);
    }

    @GET
    @Path("/{stationId}/{observationId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Observation getObservation(@PathParam("stationId") int stationId,
            @PathParam("observationId") int observationId) {
        return Observations.getInstance().getObservation(stationId, observationId);
    }

    @GET
    @Path("/{stationId}/min")
    @Produces(MediaType.APPLICATION_JSON)
    public HashMap getMin(@PathParam("stationId") int stationId, @QueryParam("fromDate") String fromDate, @QueryParam("toDate") String toDate) {
    	
        System.out.println(">>>>>>>>  Station ID = " + stationId);
        System.out.println(">>>>>>>>  fromDate = " + fromDate);
        System.out.println(">>>>>>>>  toDate = " + toDate);
        Collection<Observation> col = null;
        if (fromDate != null && toDate != null)
        	col = Observations.getInstance().getObservations(stationId, fromDate, toDate);
        else if (fromDate == null && toDate == null)
        	col = Observations.getInstance().getObservations(stationId);
        else {
        	throw new BadRequestException("Please supply both from and to dates");
        }
        
        if (col.size() > 0) {
        	Observation min = Collections.max(col, new Comparator<Observation>() {
        		@Override
        		 public int compare(Observation a, Observation b) {
                    if (a.temperature < b.temperature)
                        return 1;
                    if (a.temperature == b.temperature)
                        return 0;
                    return -1;
                }
        	});
        	HashMap value = new HashMap();
            value.put("min", min.temperature);
            return value;
        }
        
        return new HashMap();
    }


    @GET
    @Path("/{stationId}/max")
    @Produces(MediaType.APPLICATION_JSON)
    public HashMap getMax(@PathParam("stationId") int stationId, @QueryParam("fromDate") String fromDate, @QueryParam("toDate") String toDate) {

        System.out.println(">>>>>>>>  Station ID = " + stationId);
        System.out.println(">>>>>>>>  fromDate = " + fromDate);
        System.out.println(">>>>>>>>  toDate = " + toDate);
        Collection<Observation> col = null;
        if (fromDate != null && toDate != null)
        	col = Observations.getInstance().getObservations(stationId, fromDate, toDate);
        else if (fromDate == null && toDate == null)
        	col = Observations.getInstance().getObservations(stationId);
        else
        	throw new BadRequestException("Please supply both from and to dates");
        
        System.out.println(">>>>> " + col);
        if (col.size() > 0) {
        	Observation max = Collections.max(col, new Comparator<Observation>() {
        		@Override
        		 public int compare(Observation a, Observation b) {
                    if (a.temperature > b.temperature)
                        return 1;
                    if (a.temperature == b.temperature)
                        return 0;
                    return -1;
                }
        	});
        	HashMap value = new HashMap();
            value.put("max", max.temperature);
        	return value;
        }
        
        return new HashMap();
    }

    @GET
    @Path("/{stationId}/avg")
    @Produces(MediaType.APPLICATION_JSON)
    public HashMap getAvg(@PathParam("stationId") int stationId, @QueryParam("fromDate") String fromDate, @QueryParam("toDate") String toDate) {
        System.out.println(">>>>>>>>  Station ID = " + stationId);
        System.out.println(">>>>>>>>  fromDate = " + fromDate);
        System.out.println(">>>>>>>>  toDate = " + toDate);
        Collection<Observation> col = null;
        if (fromDate != null && toDate != null)
        	col = Observations.getInstance().getObservations(stationId, fromDate, toDate);
        else if (fromDate == null && toDate == null)
        	col = Observations.getInstance().getObservations(stationId);
        else
        	throw new BadRequestException("Please supply both from and to dates");
        
        if (col.size() == 0) {
        	return new HashMap();
        }
        
        float total = 0;
        for (Observation o : col) {
        	total += o.temperature;
        }
        float avg = total/col.size();
        
        HashMap value = new HashMap();
        value.put("avg", avg);
        return value;
    }
    
    @GET
    @Path("/{stationId}/nextObservationId")
    @Produces(MediaType.APPLICATION_JSON)
    public HashMap getNextObservationId(@PathParam("stationId") int stationId) {
        System.out.println(">>>>>>>>  Station ID = " + stationId);

        Collection<Observation> col = Observations.getInstance().getObservations(stationId);
        
        int maxId = 0;
        if (col.size() != 0) {
	        for (Observation o : col) {
	        	if (maxId < o.observationId)
	        		maxId = o.observationId;
	        }
        }
        
        System.out.println(">>> Next ID " + maxId);
        HashMap<String, String> value = new HashMap<String, String>();
        value.put("nextId", ""+(maxId+1));
        return value;
    }


    @GET
    @Path("/all")
    @Produces(MediaType.APPLICATION_JSON)
    public Map getAll() throws BadRequestException {
       return Observations.getInstance().observations;
    }
    
    
    @ThreadSafe
    private static final class Observations {

        private final Map<Integer, Map<Integer, Observation>> observations = new ConcurrentHashMap();
        private static Logger logger = LoggerFactory.getLogger(Observations.class);
        private static final Observations INSTANCE = new Observations();


        private Observations() {
            initialize();
        }

        public static Observations getInstance() {
            return INSTANCE;
        }

        private void initialize() {
            CsvSchema schema = CsvSchema.emptySchema().withHeader();
            CsvMapper mapper = new CsvMapper();
            ObjectReader reader = mapper.readerFor(Observation.class).with(schema);
            try {
                MappingIterator<Observation> csvData =
                        reader.readValues(Observations.class.getResourceAsStream("/data.csv"));
                csvData.readAll()
                        .stream()
                        .forEach(observation ->
                                observations.computeIfAbsent(observation.stationId, key -> new ConcurrentHashMap<>())
                                        .put(observation.observationId, observation));
            } catch (IOException ex) {
                logger.warn("Could not initialize with prepared CSV file.", ex);
            }
        }

        public Collection<Observation> getObservations(int stationId) {
            ensureExistence(stationId);
            return observations.get(stationId).values();
        }
        
        public Collection<Observation> getObservations(int stationId, String fromStr, String toStr) throws BadRequestException {
            ensureExistence(stationId);
            Collection<Observation> cloneCopy = new ArrayList<Observation>();
            cloneCopy.addAll(observations.get(stationId).values());
            
            
			try {
				Date from = DATE_FORMAT.parse(fromStr);
				Date to = DATE_FORMAT.parse(toStr);
				 
				System.out.println("Date from = " + from);
				System.out.println("Date to = " + to);
				Iterator<Observation> i = cloneCopy.iterator();
	            while (i.hasNext()) {
	            	Observation o = i.next();
	            	if (o.timestamp.compareTo(from) < 0 || o.timestamp.compareTo(to) > 0) {
	            		System.out.println("Removing " + o.temperature + " , Timestamp " + o.timestamp);
	            		i.remove();
	            	}
	            }
	            
	            return cloneCopy;
		            
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new BadRequestException("Bad Date Format.  Expect YYYY-MM-DD");
			}
           


        }

        public void add(Observation observation) {
            Observation nullIfAssociated = observations
                    .computeIfAbsent(observation.stationId, key -> new ConcurrentHashMap<>())
                    .putIfAbsent(observation.observationId, observation);

            if (nullIfAssociated != null) {
                throw new CollisionException(
                        String.format("Observation for station %s with id %s already exists.",
                                observation.stationId, observation.observationId));
            }
        }

        public Observation getObservation(int stationId, int observationId) {
            ensureExistence(stationId, observationId);
            return observations.get(stationId).get(observationId);
        }

        private void ensureExistence(int stationId, int observationId) {
            ensureExistence(stationId);
            if (!observations.get(stationId).containsKey(observationId)) {
                throw new NotFoundException();
            }
        }

        private void ensureExistence(int stationId) {
            if (!observations.containsKey(stationId)) {
                throw new NotFoundException();
            }
        }
    }
}
