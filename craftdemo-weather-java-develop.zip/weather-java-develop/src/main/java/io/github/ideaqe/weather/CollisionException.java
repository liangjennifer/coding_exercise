package io.github.ideaqe.weather;

public class CollisionException extends RuntimeException {

    public CollisionException(String message) {
        super(message);
    }
}
